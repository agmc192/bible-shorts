# Fontsource Frank Ruhl Libre

[![npm (scoped)](https://img.shields.io/npm/v/@fontsource/frank-ruhl-libre?color=brightgreen)](https://www.npmjs.com/package/@fontsource/frank-ruhl-libre) [![Generic badge](https://img.shields.io/badge/fontsource-passing-brightgreen)](https://github.com/fontsource/fontsource) [![Monthly downloads](https://badgen.net/npm/dm/@fontsource/frank-ruhl-libre)](https://github.com/fontsource/fontsource) [![Total downloads](https://badgen.net/npm/dt/@fontsource/frank-ruhl-libre)](https://github.com/fontsource/fontsource)

The CSS and web font files to easily self-host the “Frank Ruhl Libre” font. Please visit the main [Fontsource website](https://fontsource.org/fonts/frank-ruhl-libre) to view more details on this package.

## Quick Installation

Fontsource offers multiple methods to import the CSS, including using a bundler like Vite or using SASS. You can find full documentation [here](https://fontsource.org/docs/getting-started/introduction).

```javascript
npm install @fontsource/frank-ruhl-libre
```

Within your app entry file or site component, import it in.

```javascript
import "@fontsource/frank-ruhl-libre"; // Defaults to weight 400
import "@fontsource/frank-ruhl-libre/400.css"; // Specify weight
import "@fontsource/frank-ruhl-libre/400-italic.css"; // Specify weight and style
```

Supported variables:
- Weights: `[300,400,500,600,700,800,900]`
- Styles: `[normal]`
- Subsets: `[hebrew,latin,latin-ext]`

> Note: `italic` may not be supported by all fonts. To learn more about what weights and styles are supported, please visit the [Fontsource website](https://fontsource.org/fonts/frank-ruhl-libre).

Finally, you can reference the font name in a CSS stylesheet, CSS Module, or CSS-in-JS.

```css
body {
  font-family: "Frank Ruhl Libre";
}
```

## Licensing
Always make sure to read the license for each font you use. Most of the fonts in the collection use the SIL Open Font License, v1.1. Some fonts use the Apache 2 license. The Ubuntu fonts use the Ubuntu Font License v1.0.

Copyright 2015 The Frank Ruhl Libre Project Authors (https://github.com/fontef/frankruhllibre)
[OFL-1.1](https://openfontlicense.org)

## Other Notes
Font version (provided by source): `v23`.

If you have any suggestions or ideas to improve the performance of font loading or expand the existing library, feel free to star and contribute to this repository. You can share your suggestions or ideas by creating an [issue](https://github.com/fontsource/fontsource/issues).